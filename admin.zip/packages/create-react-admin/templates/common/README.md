# {{name}}

## Installation

Install the application dependencies by running:

```sh
{{installCommand}}
```

## Development

Start the application in development mode by running:

```sh
{{devCommand}}
```

## Production

Build the application in production mode by running:

```sh
{{buildCommand}}
```
