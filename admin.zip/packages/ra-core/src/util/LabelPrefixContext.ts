import { createContext } from 'react';

export const LabelPrefixContext = createContext<string>('');
