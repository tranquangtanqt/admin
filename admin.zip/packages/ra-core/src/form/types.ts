export interface InputProps {
    addField?: boolean;
    defaultValue?: any;
    input?: any;
    source: string;
}
