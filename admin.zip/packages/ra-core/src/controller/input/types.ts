export interface MatchingReferencesError {
    error: string;
}
