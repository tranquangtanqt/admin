import { createContext } from 'react';

export const BasenameContext = createContext('');
